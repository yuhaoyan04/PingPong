#!/bin/bash
set -e

echo "The udev rule installation script is currently running..."

DVSENSE_DVSCAM_VID="04b4"
DVSENSE_DVSCAM_PID="00f5"

DVSENSE_DVSLUME_VID="04b5"
DVSENSE_DVSLUME_PID="0001"

DVSENSE_WUQI320_VID="04b5"
DVSENSE_WUQI320_PID="0003"

DVSENSE_DVSYNC_VID="2207"
DVSENSE_DVSYNC_PID="0006"

DVSENSE_EVK5_VID="04b4"
DVSENSE_EVK5_PID="00c4"

UDEV_RULES_DIR="${UDEV_RULES_DIR:-/etc/udev/rules.d}"
UDEV_RULES_FILE="${UDEV_RULES_DIR}/dvsense.rules"

mkdir -p "${UDEV_RULES_DIR}"

cat > "${UDEV_RULES_FILE}" <<EOF_RULES
SUBSYSTEM=="usb", ATTR{idVendor}=="${DVSENSE_DVSCAM_VID}", ATTR{idProduct}=="${DVSENSE_DVSCAM_PID}", MODE="0666"
SUBSYSTEM=="usb", ATTR{idVendor}=="${DVSENSE_DVSLUME_VID}", ATTR{idProduct}=="${DVSENSE_DVSLUME_PID}", MODE="0666"
SUBSYSTEM=="usb", ATTR{idVendor}=="${DVSENSE_WUQI320_VID}", ATTR{idProduct}=="${DVSENSE_WUQI320_PID}", MODE="0666"
SUBSYSTEM=="usb", ATTR{idVendor}=="${DVSENSE_DVSYNC_VID}", ATTR{idProduct}=="${DVSENSE_DVSYNC_PID}", MODE="0666"
SUBSYSTEM=="usb", ATTR{idVendor}=="${DVSENSE_EVK5_VID}", ATTR{idProduct}=="${DVSENSE_EVK5_PID}", MODE="0666"
EOF_RULES

if command -v udevadm >/dev/null 2>&1; then
    udevadm control --reload-rules || true
    udevadm trigger || true
fi

echo "The udev rule installation is complete."
