import numpy as np
class Event2D:
    x: int
    y: int
    polarity: int
    timestamp: int

class EventTriggerIn:
    id: int
    polarity: int
    timestamp: int

class ApsFrame:
    def data_numpy() -> np.ndarray: ...
    def get_data_size() -> int: ...
    def width() -> int: ...
    def height() -> int: ...
    exposure_start_timestamp:int
    exposure_end_timestamp:int
class MatrixData:
    rows:int
    cols:int
    type:int
    data:np.ndarray
    
class CalibratorParameters:
    def __init__(self): ...
    camera_serial: str
    dvs_cols: int
    dvs_rows: int
    aps_cols: int
    aps_rows: int
    camera_matrix: MatrixData
    dist_coeffs: MatrixData
    affine_matrix: dict[str, MatrixData]
    rotation:np.ndarray
    translation:np.ndarray

class DvsFileInfo:
    def __init__(self): ...
    serial_number: str
    start_timestamp: int
    end_timestamp: int
    aps_start_timestamp: int
    max_events: int
    dvs_width: int
    dvs_height: int

class LogLevelType:
    TRACE = 0
    DEBUG = 1
    INFO = 2
    WARN = 3
    ERR = 4
    FATAL = 5

class Logger:
    def setLogLevel(self, level: LogLevelType) -> None: ...
    def getLogLevel(self) -> LogLevelType: ...
    def log(self, level: LogLevelType, message: str) -> None: ...
    def trace(self, message: str) -> None: ...
    def debug(self, message: str) -> None: ...
    def info(self, message: str) -> None: ...
    def warn(self, message: str) -> None: ...
    def error(self, message: str) -> None: ...
    def fatal(self, message: str) -> None: ...

def getLogger() -> Logger: ...
def log_trace(message: str) -> None: ...
def log_debug(message: str) -> None: ...
def log_info(message: str) -> None: ...
def log_warn(message: str) -> None: ...
def log_error(message: str) -> None: ...
def log_fatal(message: str) -> None: ...
    